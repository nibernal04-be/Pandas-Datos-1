# Proyecto Pandas - Calidad del Agua

Proyecto desarrollado para la asignatura Programación de Métodos Numéricos.

## Integrantes
- Nicoll Bernal
- Integrante 2
- Integrante 3
- Integrante 4

## Herramientas utilizadas
- Python
- Pandas
- Jupyter Notebook

## Dataset
Archivo: resultados_calidad_hidrica.csv

## Objetivo
Analizar datos ambientales utilizando pandas y aplicar filtros, estadísticas y diagnósticos de calidad del agua.
